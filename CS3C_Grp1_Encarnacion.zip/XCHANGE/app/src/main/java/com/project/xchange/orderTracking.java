package com.project.xchange;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.project.xchange.adapter.CartAdapter;
import com.project.xchange.adapter.OrderAdapter;
import com.project.xchange.model.Cart;
import com.project.xchange.model.Order_List;

import java.util.ArrayList;

public class orderTracking extends AppCompatActivity {
    private static final String TAG = "orderTracking";

    private ArrayList<Order_List> orderItems;
    private OrderAdapter orderAdapter;
    RecyclerView orderRecylerView;

    private Button gobackbtn;
    private  userHandler usHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_tracking);

        usHandler = new userHandler();

        gobackbtn = (Button) findViewById(R.id.goback_btn);
        gobackbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        getOrder();
    }

    private void getOrder() {

        orderRecylerView = findViewById(R.id.orderTrack);
        orderRecylerView.setLayoutManager(new LinearLayoutManager(this));

        orderItems = new ArrayList<Order_List>();
        orderAdapter = new OrderAdapter(orderItems, this);
        orderRecylerView.setAdapter(orderAdapter);


        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Order_Items");
        DatabaseReference childRef =  ref.child(usHandler.getUser());
        childRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Log.d(TAG, "initImageBitmaps: preparing bitmaps.");
                for (DataSnapshot snapshot1 : snapshot.getChildren()){
                    String Key = snapshot1.getKey();
                    Order_List order = snapshot1.getValue(Order_List.class);
                    orderItems.add(order);
                }
                orderAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
}