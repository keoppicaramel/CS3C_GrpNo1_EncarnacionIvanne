package com.project.xchange;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class create_request extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_request);
    }
}