package com.project.xchange.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.project.xchange.R;
import com.project.xchange.confirmOrderedItems;
import com.project.xchange.model.Cart;
import com.project.xchange.model.Cold_Storage;
import com.project.xchange.model.Order_List;
import com.project.xchange.userHandler;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderHolder> {

    private ArrayList<Order_List> order_lists;
    private Context context;

    public OrderAdapter(ArrayList<Order_List> order_lists, Context context) {
        this.order_lists = order_lists;
        this.context = context;
    }

    @NonNull
    @Override
    public OrderAdapter.OrderHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.order_track_list, parent, false);
        OrderHolder holder = new OrderHolder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull OrderAdapter.OrderHolder holder, int position) {
        Order_List order = order_lists.get(position);

        holder.str_id = order.getStorageKey();
        holder.str_key  = order.getKey();

        holder.text_name.setText(order.getProductName());
        holder.text_price.setText("Item Price: "+ order.getProductPrice());
        holder.text_quantity.setText("Quantity: "+String.valueOf(
                Integer.valueOf(order.getProductQuantity())));

        Double total = Double.valueOf(order.getProductPrice()) * Integer.valueOf(order.getProductQuantity());

        holder.text_totalP.setText("Total Price: "+total);

        Glide.with(context).load(order.getProductImage()).into(holder.imgView);

        holder.cfrm_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, confirmOrderedItems.class);
                intent.putExtra("storageKey", holder.str_id);
                intent.putExtra("orderKey", holder.str_key);
                context.startActivity(intent);
                }
        });


        holder.delete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "You Cannot Delete a Confirm Order", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return order_lists.size();
    }


    public class OrderHolder extends RecyclerView.ViewHolder{

        private TextView text_name, text_price, text_status, text_quantity, text_totalP;
        private ImageView imgView;

        private userHandler userhandler;

        private DatabaseReference child_ref;

        private Button cfrm_btn, delete_btn;

        String str_id, str_key, str_image, str_price, str_quantity;

        public OrderHolder(@NonNull View itemView) {
            super(itemView);

            text_name = (TextView) itemView.findViewById(R.id.itemName);
            text_price = (TextView) itemView.findViewById(R.id.itemPrice);
            text_status = (TextView) itemView.findViewById(R.id.itemStatus);
            text_quantity = (TextView) itemView.findViewById(R.id.itemQuantity);
            text_totalP = (TextView) itemView.findViewById(R.id.itemTotalPrice);

            imgView = (ImageView) itemView.findViewById(R.id.item_image);

            cfrm_btn = (Button) itemView.findViewById(R.id.receive_btn);
            delete_btn = (Button) itemView.findViewById(R.id.delete_btn);

            userhandler = new userHandler();

            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("users_information");
            child_ref =  ref.child(userhandler.getUser()).child("Cart").getRef();
        }
    }
}
