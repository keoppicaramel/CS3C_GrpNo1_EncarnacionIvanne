package com.project.xchange;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.project.xchange.model.Cold_Storage;
import com.project.xchange.model.Order_List;

public class confirmOrderedItems extends AppCompatActivity {
    private static final String TAG = "confirmOrderedItems";

    private ImageView image_view;
    private TextView item_name, item_quantity, item_price;

    private Button confirmBtn;

    private userHandler userhandler;

    private String transactionId;

    private LinearLayout splashLayout;
    private LinearLayout confirmItem;

    private String itemKey, itemImage,  itemPrice,itemName, itemQuantity, key_storage, key_order;

    private userHandler user_handler;
    private DatabaseReference order_ref;
    private DatabaseReference cold_ref;

    public static final int TASK_A = 1;

    Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what){
                case TASK_A:
                    splashLayout.setVisibility(View.GONE);

                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_ordered_items);

//      databases
        order_ref = FirebaseDatabase.getInstance().getReference("Order_Items");
        cold_ref = FirebaseDatabase.getInstance().getReference("Cold_Storage");

        user_handler = new userHandler();

        itemImage = getIntent().getStringExtra("itemImage");
        itemPrice = getIntent().getStringExtra("itemPrice");
        itemName = getIntent().getStringExtra("itemName");
        itemQuantity = getIntent().getStringExtra("itemQuantity");

        item_name = (TextView) findViewById(R.id.item_name );
        item_quantity = (TextView) findViewById(R.id.item_quantity);
        item_price = (TextView) findViewById(R.id.item_price);
        image_view = (ImageView) findViewById(R.id.image_View);

        splashLayout = (LinearLayout) findViewById(R.id.splashLayout);
        confirmItem = (LinearLayout) findViewById(R.id.layout_confirmItem);

        key_storage = getIntent().getStringExtra("storageKey");
        key_order = getIntent().getStringExtra("orderKey");

        confirmBtn = (Button) findViewById(R.id.confirm_btn);
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Runnable runnableObj = new Runnable() {
                    @Override
                    public void run() {
                        cold_ref.child(user_handler.getUser()).child(key_storage).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                Cold_Storage cold_data = snapshot.getValue(Cold_Storage.class);
                                    double amountDouble = cold_data.getAmount();
                                    int sendAmount = (int) amountDouble;
                                    String userId = cold_data.getSenders_id();
                                    String receiverId = cold_data.getReceivers_id();

                                    try {
                                        transactionId = String.valueOf(SystemClock.elapsedRealtime());
                                        if(user_handler.transactionHandler("Freeze", userId, receiverId, transactionId, sendAmount)) {
                                            Thread.sleep(500);
                                            user_handler.updateAccountBalance(receiverId, sendAmount);
                                            if(user_handler.transactionHandler("Receive", receiverId, userId, transactionId, sendAmount)) {
                                                Thread.sleep(500);
                                            }
                                        }
                                    }catch (Exception e){
                                        e.printStackTrace();
                                    }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });

                        try {
                            Thread.sleep(500);
                            cold_ref.child(user_handler.getUser()).child(key_storage).removeValue();
                            Thread.sleep(500);
                            order_ref.child(user_handler.getUser()).child(key_order).removeValue();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        handler.sendEmptyMessage(TASK_A);
                    }
                };

                confirmItem.setVisibility(View.GONE);
                splashLayout.setVisibility(View.VISIBLE);
                Thread thread = new Thread(runnableObj);
                thread.start();
            }
        });



        getOrderData();
    }

    private void getOrderData() {
        order_ref.child(user_handler.getUser()).child(key_order).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Order_List order_list = snapshot.getValue(Order_List.class);
                itemImage = order_list.getProductImage();
                itemPrice = String.valueOf(order_list.getProductPrice());
                itemName = order_list.getProductName();
                itemQuantity = String.valueOf(order_list.getProductQuantity());

                item_name.setText(itemName);
                item_quantity.setText(itemQuantity);
                item_price.setText(itemPrice);
                Glide.with(getApplicationContext()).load(itemImage).into(image_view);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }

    private void sendFreezeAmount(){
        }

}