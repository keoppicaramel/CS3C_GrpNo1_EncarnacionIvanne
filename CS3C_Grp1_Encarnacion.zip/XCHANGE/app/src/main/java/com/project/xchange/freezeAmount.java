package com.project.xchange;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.UiAutomation;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.project.xchange.model.Cold_Storage;

import java.util.ArrayList;

public class freezeAmount extends AppCompatActivity {

    private ListView freezeView;
    private ArrayAdapter<String> arrayAdapterFreeze;
    private ArrayList<String> freezeList;

    private userHandler userhandler;;

    private Button gobackbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freeze_amount);

        userhandler = new userHandler();

        freezeView = (ListView) findViewById(R.id.freezeView);
        freezeList = new ArrayList<String>();
        arrayAdapterFreeze = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, freezeList);
        freezeView.setAdapter(arrayAdapterFreeze);

        DatabaseReference cold_ref = FirebaseDatabase.getInstance().getReference("Cold_Storage");
        cold_ref.child(userhandler.getUser()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                freezeList.clear();
                for(DataSnapshot snapshot1 : snapshot.getChildren()){
                    String key = snapshot1.getKey();
                    Cold_Storage coldData = snapshot1.getValue(Cold_Storage.class);
                    String output = "Ref, ID: \t" + key + "\nFreeze Amount: \t" + coldData.getAmount();
                    freezeList.add(output);
                }
                arrayAdapterFreeze.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        gobackbtn = (Button) findViewById(R.id.goback_btn);
        gobackbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}